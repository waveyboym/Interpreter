var searchData=
[
  ['variablenode_0',['VariableNode',['../d6/dfb/a00172.html',1,'']]]
];
