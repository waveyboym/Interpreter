var searchData=
[
  ['statement_5fdatatype_0',['STATEMENT_DATATYPE',['../dc/d87/a00032_a9b9eef56b8fb7385f8ee50966e63ee6c.html#a9b9eef56b8fb7385f8ee50966e63ee6c',1,'parser.h']]]
];
