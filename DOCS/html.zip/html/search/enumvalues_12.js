var searchData=
[
  ['var_5falready_5fexists_0',['VAR_ALREADY_EXISTS',['../dd/dad/a00005_a02460d0504327ff4596d38ca3f0148e2.html#a02460d0504327ff4596d38ca3f0148e2a7d55e513ce6a506a6ea11bf815acbc11',1,'Exceptions.h']]],
  ['variable_5fnotfound_1',['VARIABLE_NOTFOUND',['../dd/dad/a00005_a02460d0504327ff4596d38ca3f0148e2.html#a02460d0504327ff4596d38ca3f0148e2a49b62e73c8e6082f5d02bb027c459e66',1,'Exceptions.h']]]
];
