var searchData=
[
  ['beginlocalscope_0',['BEGINLOCALSCOPE',['../d1/d44/a00098_af579444e854ea39b5cc5661f4f918578.html#af579444e854ea39b5cc5661f4f918578a50fa3069cc8144e5f7161538467a1ad2',1,'tokens.h']]],
  ['buitinfunction_1',['BUITINFUNCTION',['../d1/d44/a00098_a0777bb96b9c2e0dca66140125bb8b169.html#a0777bb96b9c2e0dca66140125bb8b169aa2696097a2a9317cdcc422bce108cc68',1,'tokens.h']]]
];
