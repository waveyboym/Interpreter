var searchData=
[
  ['stringnode_0',['StringNode',['../de/d38/a00160.html',1,'']]]
];
