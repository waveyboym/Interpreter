var searchData=
[
  ['cannot_5fappend_5fbooleans_0',['CANNOT_APPEND_BOOLEANS',['../dd/dad/a00005_a02460d0504327ff4596d38ca3f0148e2.html#a02460d0504327ff4596d38ca3f0148e2a5f5bbcd28d2c3a9881b05f17c519e87a',1,'Exceptions.h']]],
  ['closingscope_1',['CLOSINGSCOPE',['../dd/dad/a00005_a02460d0504327ff4596d38ca3f0148e2.html#a02460d0504327ff4596d38ca3f0148e2ab020e2188e61a3b5b9852c365e85b96e',1,'Exceptions.h']]]
];
