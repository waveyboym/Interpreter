var searchData=
[
  ['manager_0',['manager',['../d1/d88/a00128.html',1,'']]]
];
