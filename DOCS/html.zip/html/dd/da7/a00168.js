var a00168 =
[
    [ "datatype", "dd/da7/a00168_a9c4544a42f0b419a77971dafe938ded4.html#a9c4544a42f0b419a77971dafe938ded4", null ],
    [ "expression", "dd/da7/a00168_a8e0766320caf321264686d917f2cb6af.html#a8e0766320caf321264686d917f2cb6af", null ]
];