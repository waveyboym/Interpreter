var a00116 =
[
    [ "booleanval", "d4/d3e/a00116_a384463a35f36f129f333300bc9cc8cb4.html#a384463a35f36f129f333300bc9cc8cb4", null ],
    [ "isbooleanval", "d4/d3e/a00116_a7a8bd5d66185421efe4901236a3e86fa.html#a7a8bd5d66185421efe4901236a3e86fa", null ],
    [ "isnumberval", "d4/d3e/a00116_a8599900209d8222d211ec6e9dcd89b39.html#a8599900209d8222d211ec6e9dcd89b39", null ],
    [ "iswordval", "d4/d3e/a00116_a8f0a2f40628747a60139f1e4859e87b6.html#a8f0a2f40628747a60139f1e4859e87b6", null ],
    [ "numberval", "d4/d3e/a00116_a28699359f9ccbc1bbd840ab6d2035e82.html#a28699359f9ccbc1bbd840ab6d2035e82", null ],
    [ "wordval", "d4/d3e/a00116_aff47ad6ec6e2f696f14f65e0263d2641.html#aff47ad6ec6e2f696f14f65e0263d2641", null ]
];