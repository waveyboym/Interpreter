var a00032 =
[
    [ "parser", "d5/deb/a00132.html", "d5/deb/a00132" ],
    [ "PARSER_H", "dc/d87/a00032_a1fa0f793a26a00557cec87403e19a26c.html#a1fa0f793a26a00557cec87403e19a26c", null ],
    [ "STATEMENT_DATATYPE", "dc/d87/a00032_a9b9eef56b8fb7385f8ee50966e63ee6c.html#a9b9eef56b8fb7385f8ee50966e63ee6c", [
      [ "NUMBER_DT", "dc/d87/a00032_a9b9eef56b8fb7385f8ee50966e63ee6c.html#a9b9eef56b8fb7385f8ee50966e63ee6ca7b71e70e4eb695883a4fc8150fa80d2e", null ],
      [ "WORD_DT", "dc/d87/a00032_a9b9eef56b8fb7385f8ee50966e63ee6c.html#a9b9eef56b8fb7385f8ee50966e63ee6caaad59e17696cb3584db80df343fdc453", null ],
      [ "NULL_STATEMENT_DATATYPE", "dc/d87/a00032_a9b9eef56b8fb7385f8ee50966e63ee6c.html#a9b9eef56b8fb7385f8ee50966e63ee6ca1162a4107d1aa1bd6f22cbe3235e37c3", null ],
      [ "STATEMENT_DATATYPE_SIZE", "dc/d87/a00032_a9b9eef56b8fb7385f8ee50966e63ee6c.html#a9b9eef56b8fb7385f8ee50966e63ee6ca245def697b8f151808b4f184f31d0b34", null ]
    ] ]
];