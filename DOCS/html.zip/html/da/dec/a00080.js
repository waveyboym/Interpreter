var a00080 =
[
    [ "tokenNode", "db/ddf/a00164.html", "db/ddf/a00164" ],
    [ "expressionData", "dd/da7/a00168.html", "dd/da7/a00168" ]
];