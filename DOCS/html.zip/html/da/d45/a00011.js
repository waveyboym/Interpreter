var a00011 =
[
    [ "returnNumberValues", "d1/dd6/a00108.html", "d1/dd6/a00108" ],
    [ "returnStringValues", "db/d57/a00112.html", "db/d57/a00112" ],
    [ "returnValues", "d4/d3e/a00116.html", "d4/d3e/a00116" ],
    [ "Interpreter", "d4/d98/a00120.html", "d4/d98/a00120" ],
    [ "DATATYPES", "da/d45/a00011_a1f258dd5ff27a072720c060e41aabaa0.html#a1f258dd5ff27a072720c060e41aabaa0", null ]
];