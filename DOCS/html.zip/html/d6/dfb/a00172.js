var a00172 =
[
    [ "VariableNode", "d6/dfb/a00172_ada20d58e92c020d97d9c9201397a5644.html#ada20d58e92c020d97d9c9201397a5644", null ],
    [ "__represent__", "d6/dfb/a00172_a5cfa10055e845b16e633aad729bd3e67.html#a5cfa10055e845b16e633aad729bd3e67", null ],
    [ "alreadyExistingVariable", "d6/dfb/a00172_a48f8bb0b441c313f57e46093d72ec14b.html#a48f8bb0b441c313f57e46093d72ec14b", null ],
    [ "getThisVariableobject", "d6/dfb/a00172_a2e0096b35a8d3f591b997284b318e233.html#a2e0096b35a8d3f591b997284b318e233", null ],
    [ "pushIntoVector", "d6/dfb/a00172_abe1d0fa82048b6b44f1887191db5c49e.html#abe1d0fa82048b6b44f1887191db5c49e", null ],
    [ "reassignExistingVariable", "d6/dfb/a00172_a411ef86ddcee337f62eaeb302d48ba3a.html#a411ef86ddcee337f62eaeb302d48ba3a", null ],
    [ "appendData", "d6/dfb/a00172_a3271c2b4a83380e2ddfbee169d3fd3d5.html#a3271c2b4a83380e2ddfbee169d3fd3d5", null ],
    [ "appendType", "d6/dfb/a00172_a6b2f5cd6f45efe0cff70f0cca7eb903a.html#a6b2f5cd6f45efe0cff70f0cca7eb903a", null ],
    [ "assignedData", "d6/dfb/a00172_a5cca1f950d65a717fb0f7d360dd1a074.html#a5cca1f950d65a717fb0f7d360dd1a074", null ],
    [ "stackNUMBERvector", "d6/dfb/a00172_aa4460f6ccb5784077c0ad667b7206239.html#aa4460f6ccb5784077c0ad667b7206239", null ],
    [ "stackWORDvector", "d6/dfb/a00172_a4f228ca668f5de356abaeaa93b7b9dc4.html#a4f228ca668f5de356abaeaa93b7b9dc4", null ],
    [ "varName", "d6/dfb/a00172_ab09ab67ee5a7a89379ac3303b2b7700e.html#ab09ab67ee5a7a89379ac3303b2b7700e", null ]
];